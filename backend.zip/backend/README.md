## To Run this Project follow below:

```bash
python3 -m venv venv
source venv/bin/activate
pip3 install -r requirements.txt
python3 manage.py makemigrations
python3 manage.py migrate
python3 manage.py runserver
```

#### There is a File "DjoserAuth.postman_collection" which has Postman Collection You can import this file in your postman to test this API

